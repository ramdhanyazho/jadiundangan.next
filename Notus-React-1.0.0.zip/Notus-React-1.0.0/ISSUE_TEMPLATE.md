<!--
 IMPORTANT: Please use the following link to create a new issue:

  https://www.creative-tim.com/new-issue/notus-react?ref=nr-new-issue

**If your issue was not created using the app above, it will be closed immediately.**
-->

<!--
Love Creative Tim? Do you need Angular, React, Vuejs or HTML? You can visit:
👉  https://www.creative-tim.com/bundles?ref=nr-new-issue
👉  https://www.creative-tim.com?ref=nr-new-issue
-->
